import React from 'react'

const Settings = () => {
  return (
    <div>
      Admin Setting
    </div>
  )
}

export default Settings
